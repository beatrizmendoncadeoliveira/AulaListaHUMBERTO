package br.com.colecoes.teste;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.com.colecoes.beans.Cargo;

public class TesteLista {

	public static void main(String[] args) {
		
	List<Cargo> lista=new ArrayList<Cargo>();
	
	lista.add(new Cargo("ESTAGIARIO","JR",3000));

	lista.add(new Cargo("DBA","TRAINEE",1500));

	lista.add(new Cargo("ANALISTA","JR",400));
	Collections.sort(lista);
	for(Cargo c:lista) {

		System.out.println(c.getNome());
	
		System.out.println(c.getNivel());
		
		System.out.println(c.getSalario());
		System.out.println(" ");
		
	
		
	}
		
	}

}
