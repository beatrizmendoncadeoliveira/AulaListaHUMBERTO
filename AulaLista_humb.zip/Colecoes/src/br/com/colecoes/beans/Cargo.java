package br.com.colecoes.beans;

public class Cargo implements Comparable<Cargo>{
	private String nome;
	private String nivel;
	private double salario;

//define um padrao quando quer comparar algo
	//Comparable<Cargo> vou comparar cargo com cargo
	
	/*
	 * ordem de salario
	public int compareTo(Cargo outro) {
		//do tipo int porque fala de indice
		//defino quando ele retorna 1=vai p baixo(ou seja � maior,desce)
		//defino quando retorna 0 que sao iguais
		//defino quando ele retorna -1 quando for menor
		if(this.salario<outro.salario) {
			return -1;
		}
		else if(this.salario>outro.salario) {
			return 1;
		}else {
			return 0;
		}
	}
	
	
	*/
	//ordem de nome
	public int compareTo(Cargo outro) {
		return this.nome.compareTo(outro.nome);
	}
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNivel() {
		return nivel;
	}
	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public Cargo(String nome, String nivel, double salario) {
		super();
		this.nome = nome;
		this.nivel = nivel;
		this.salario = salario;
	}
	public Cargo() {
		super();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
